import streamlit as st
import joblib
import model_ai

# Configuração da página
st.title("Classificação de Faixa Etária")

# Campo para inserir a idade
idade_input = st.text_input("Insira sua idade:")

# Botão para enviar a idade
if st.button("Classificar Faixa Etária"):
    if idade_input:  # Verifica se o campo foi preenchido
        try:
            idade = int(idade_input)  # Converte para inteiro
            # Carrega o modelo treinado
            modelo = joblib.load('modelo_knn.pkl')
            # Faz a previsão
            faixa_etaria = model_ai.prever_faixa_etaria(modelo, idade)
            st.write(f"A faixa etária correspondente é: {faixa_etaria}")
        except ValueError:
            st.write("Por favor, insira um número válido.")
    else:
        st.write("O campo de idade não pode estar vazio.")