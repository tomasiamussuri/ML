def calcular_media(nota1, nota2):
    media = (nota1 + nota2) / 2 
    return media
