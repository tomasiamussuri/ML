# Importar as bibliotecas necessárias
import pandas as pd
import numpy as np
import joblib
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier
from sklearn.metrics import classification_report, accuracy_score

# Ler o arquivo CSV
df = pd.read_csv('faixa_etaria.csv')

# Converter as faixas etárias para valores numéricos
df['Classe'] = df['faixa_etaria'].map({
    "Criança": 0, "Adolescente": 1, "Adulto": 2, "Idoso": 3
})

# Separar as features (X) e o target (y)
X = df[['idade']]
y = df['Classe']

# Dividir os dados em treino e teste
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=42)

# Criar o modelo KNN
knn = KNeighborsClassifier(n_neighbors=3)

# Treinar o modelo
knn.fit(X_train, y_train)

# Fazer previsões
y_pred = knn.predict(X_test)

# Avaliar o modelo
print("Acurácia:", accuracy_score(y_test, y_pred))
print("Relatório de classificação:\n", classification_report(y_test, y_pred))

# Prever a faixa etária para uma nova idade
#idade_nova = np.array([[34]])
#faixa_etaria_pred = knn.predict(idade_nova)
#faixas = {0: "Criança", 1: "Adolescente", 2: "Adulto", 3: "Idoso"}
#print("A faixa etária para idade 34 é:", faixas[faixa_etaria_pred[0]])


def prever_faixa_etaria(modelo, idade):
    """
    Função para prever a faixa etária com base na idade fornecida.

    Parâmetros:
    - modelo_knn: modelo KNN treinado (modelo_knn.pkl)
    - idade: int, idade da pessoa.

    Retorna:
    - Texto correspondente à faixa etária (Criança, Adolescente, Adulto ou Idoso)
    """
    # Formatar a idade como array 2D para a entrada do modelo
    idade_array = np.array([[idade]])
    
    # Fazer a previsão da classe (0, 1, 2, 3)
    faixa_etaria_pred = modelo.predict(idade_array)
    
    # Mapeamento da classe para o texto correspondente
    faixas = {0: "Criança", 1: "Adolescente", 2: "Adulto", 3: "Idoso"}
    
    # Retornar o texto correspondente à previsão
    return faixas[faixa_etaria_pred[0]]




#Salvar o modelo
joblib.dump(knn, 'modelo_knn.pkl')

print("Modelo salvo com sucesso!")